package com.example.farm2;

import android.widget.EditText;

public class ReadProductDetails {

    public String pName, pPrice;

    public ReadProductDetails(EditText editTextProductName, EditText editTextProductPrice) {

        this.pName = editTextProductName.getText().toString();

        this.pPrice = editTextProductPrice.getText().toString();

    }

}