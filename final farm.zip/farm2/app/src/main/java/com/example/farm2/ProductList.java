package com.example.farm2;

public class ProductList {

    public String pName, pPrice;

    public ProductList() {};

    public String getProductName() {
        return pName;
    }

    public void setProductName(String pName) {
        this.pName = pName;
    }

    public String getProductPrice() {
        return pPrice;
    }

    public void setProductPrice(String pPrice) {
        this.pPrice = pPrice;
    }

}