package com.example.farm2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SellActivity extends AppCompatActivity {

    private EditText editTextProductName, editTextProductPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);
        getSupportActionBar().setTitle("SELL");

        editTextProductName = findViewById(R.id.inputProductName);
        editTextProductPrice = findViewById(R.id.inputProductPrice);

        Button submitButton = findViewById(R.id.btnSubmit);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //obtain entered data
                String textProductName = editTextProductName.getText().toString();
                String textProductPrice = editTextProductPrice.getText().toString();

                //input data

                registerProducts(textProductName, textProductPrice);

            }
        });

    }

    // function to generate a random string of length n
    static String getAlphaNumericString(int n) {

        // chose a Character random from this String
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
                "0123456789" +
                "abcdefghijklmnopqrstuvxyz";

        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            // generate a random number between
            // 0 to AlphaNumericString variable length
            int index
                    = (int)(AlphaNumericString.length() *
                    Math.random());

            // add Character one by one in end of sb
            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }
    private void registerProducts(String textProductName, String textProductPrice) {

        ///enter data to firebase
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        FirebaseUser firebaseUser = auth.getCurrentUser();

        ReadProductDetails writeProductDetails = new ReadProductDetails(editTextProductName, editTextProductPrice);

        DatabaseReference ref = database.getReference("Products");

        ref.child(getAlphaNumericString(11)).setValue(writeProductDetails).addOnCompleteListener(new OnCompleteListener < Void > () {

            @Override
            public void onComplete(@NonNull Task < Void > task) {

                Toast.makeText(SellActivity.this, "Product successfully submitted", Toast.LENGTH_LONG).show();
                finish();

            }
        });

    }

}